Free to use, if code is used in a retail product, please include credit to Micah Berninghausen 4/23/2024.
Compiled with UE5.3.2 (calls should work for all UE5+)

Details/Tutorial and code by @gamedevMicah / Micah Berninghausen / Aggressive Mastery LLC / r/diepepsi 

Youtube Video on Code : "Nanite Niagara"
www.youtube.com/watch?v=5Wp9mqYftt0

Unreal Engine Forum Tutorial:
https://dev.epicgames.com/community/learning/tutorials/w6wG/unreal-engine-nanite-niagara-gpu-particle-renderer-and-rendering-of-100-000-particles-using-a-single-niagara-system-with-33-different-meshs-blueprint-and-c-code-performance-review

Additional Links
https://twitter.com/GameDevMicah/status/1782435425426329795

To Install:
1. Copy Plugin into your Project Plugins Folder (projectname/plugins/)
2. Startup Unreal Engine 5.3.2 (any other version may have issues as I built this with just that version.)
3. "rebuild ?" say yes
4. look for "plugin content" as an example level lives in there you can review. 

Hit me up for help! 
@gamedevMicah / Micah Berninghausen / Aggressive Mastery LLC 